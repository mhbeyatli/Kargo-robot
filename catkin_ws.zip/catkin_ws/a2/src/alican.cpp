#include "ros/ros.h"
#include "std_msgs/String.h"
#include "geometry_msgs/Twist.h"
#include "sensor_msgs/LaserScan.h"
#include <iostream>
#include "geometry_msgs/Transform.h"
#include <tf/transform_listener.h>
#include <tf/tf.h>

#include <sstream>

ros::Subscriber sub_; 
ros::Publisher pub_;
geometry_msgs::Transform curr_waypoint;

void waypoint_cb(const geometry_msgs::Transform::ConstPtr& msg)
{                 
    curr_waypoint=*msg;
}

int main(int argc, char **argv)
{

	ros::init(argc, argv, "followPath");
	ros::NodeHandle n;
	sub_ = n.subscribe("/waypoint_cmd", 1000,waypoint_cb); 
	pub_ = n.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/navi", 1000);

	tf::TransformListener listener;

	ros::Rate one_hz(1);
	while(ros::ok()){
	  ros::spinOnce();
	  
	  tf::StampedTransform transform;
	  
	  try{
	    
	    listener.lookupTransform("/odom", "/base_link", ros::Time(0), transform);
	  }
	  catch (tf::TransformException ex){
	    ROS_ERROR("%s",ex.what());
	    ros::Duration(1.0).sleep();
	  }
	  
	  
	  //std::cout<<"Robot position (x,y): ("<<transform.getOrigin().x()<<","<<transform.getOrigin().y()<<")"<<std::endl;
	  
	  tf::Vector3 axisR=transform.getRotation().getAxis();
	  double angleR=transform.getRotation().getAngle();
	  double thetaR=angleR*axisR[2];
	  //std::cout<<"Robot orientation (theta): ("<<thetaR<<")"<<std::endl<<std::endl;



	  //std::cout<<"Current waypoint (x,y): ("<<curr_waypoint.translation.x<<","<<curr_waypoint.translation.y<<")"<<std::endl;
	  
	  tf::Quaternion quat(curr_waypoint.rotation.x,curr_waypoint.rotation.y,curr_waypoint.rotation.z,curr_waypoint.rotation.w);
	  tf::Vector3 axisW=quat.getAxis();
	  double angleW=quat.getAngle();
	  double thetaW=angleW*axisW[2];
	  //std::cout<<"Current waypoint (theta): ("<<thetaW<<")"<<std::endl<<std::endl;


	  geometry_msgs::Twist twist;

	  
	  twist.linear.x = curr_waypoint.translation.x - transform.getOrigin().x();
	  twist.linear.y = curr_waypoint.translation.y - transform.getOrigin().y();

	  if(twist.linear.x<0.001 && twist.linear.x > 0){twist.linear.x=0.001;}
	  else if(twist.linear.x>-0.01 && twist.linear.x < 0 ){twist.linear.x=-0.2;}

	  if(twist.linear.y<0.01 && twist.linear.y > 0){twist.linear.y=0.01;}
	  else if(twist.linear.y>-0.01 && twist.linear.y < 0 ){twist.linear.y=-0.01;}

	  twist.angular.z = thetaW - thetaR;

	  if(twist.angular.z<0.001 && twist.angular.z > 0){twist.angular.z = 0.001;}
	  else if(twist.angular.z > -0.001 && twist.angular.z < 0){twist.angular.z = -0.001;}

	  std::cout<<"x y z ("<<twist.linear.x<<"------"<<twist.linear.y<<"------"<<twist.angular.z<<")"<<std::endl<<std::endl;

	  pub_.publish(twist);

	  
	  one_hz.sleep();
	}

	return 0;

}
