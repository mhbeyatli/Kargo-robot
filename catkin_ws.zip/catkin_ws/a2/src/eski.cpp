#include "ros/ros.h"
#include <iostream>
#include "geometry_msgs/Transform.h"
#include <tf/tf.h>
#include <tf/transform_listener.h>

ros::Subscriber sub;
ros::Publisher pub;

#define PI 3.141592

bool first;

geometry_msgs::Transform curr_waypoint;


void waypoint_cb(const geometry_msgs::Transform::ConstPtr& msg)
{                 
    curr_waypoint=*msg;
}

int main(int argc, char **argv){

	ros::init(argc, argv, "waypoint");
	ros::NodeHandle n;
	sub = n.subscribe("/waypoint_cmd", 1000,waypoint_cb); 
	pub = n.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/navi", 1000);
	
	tf::TransformListener listener;
	
	first = 1;
	
	ros::Rate loop(10.0);
	while(ros::ok()){
		ros::spinOnce();
	  
		tf::StampedTransform transform;
	  
		try{
	    
			listener.lookupTransform("/odom", "/base_link", ros::Time(0), transform);
		}
		
		catch (tf::TransformException ex){
			ROS_ERROR("%s",ex.what());
			ros::Duration(1.0).sleep();
		}
	  
		tf::Vector3 turtleAxis=transform.getRotation().getAxis();
		double turtleAngle=transform.getRotation().getAngle();
		double turtleTheta=turtleAngle * turtleAxis[2];
		
		if(turtleTheta <0) turtleTheta = turtleTheta + 2*PI;
	  
		tf::Quaternion wQuat(curr_waypoint.rotation.x,curr_waypoint.rotation.y,curr_waypoint.rotation.z,curr_waypoint.rotation.w);
		tf::Vector3 wAxis=wQuat.getAxis();
		double wAngle=wQuat.getAngle();
		double wTheta=wAngle * wAxis[2];
	  
		geometry_msgs::Twist twist;
	  
		float length = sqrt(pow(transform.getOrigin().x() - curr_waypoint.translation.x, 2) + pow(transform.getOrigin().y() - curr_waypoint.translation.y, 2));
	  
		
	  
		double arctan = atan2(curr_waypoint.translation.y - transform.getOrigin().y(), curr_waypoint.translation.x - transform.getOrigin().x());
		if (arctan < 0) arctan = arctan + 2*PI;
		
		
		double theta = -1 * fabs(turtleTheta - arctan);
		
		
		
		
		//theta = fmod((-4.0 * (turtleTheta - arctan)), 2*PI);		//DENEME
		
		
		/*if(transform.getOrigin().x() < 0 && first) {
			theta = theta + PI; 
			first=0;
			theta = fmod(theta, PI);
		}
		*/
		
		//if(turtleTheta - arctan < 0)
			//theta = -1 * theta;
		
		
		//if(arctan > 3.12) arctan = 3.12;			//DENEME
		//else if(arctan < -3.12) arctan = -3.12;		//DENEME
		/*if(arctan < 3.12)
			theta = -4.0 * (turtleTheta - arctan);
		else 
			theta = -4.0 * (arctan - turtleTheta);*/
			
		twist.angular.z = theta;
		twist.linear.x = length;
		/*if(first) twist.linear.x = 0.5 * length;
	    else twist.linear.x = length;*/
	  
		  
	  
	  
	  
	  /*if(twist.angular.x < 0.005 && twist.angular.x > 0) twist.angular.x = 0.005;
	  else if(twist.angular.x > -0.005 && twist.angular.x < 0) twist.angular.x = -0.005;
	  */
	  
		std::cout << "\n\n\n\nlinear x = " << twist.linear.x << "   angular z = " << twist.angular.z << " (" << twist.angular.z * (180.0/PI) << ")";
		std::cout << "\nwaypoint x , y = " << curr_waypoint.translation.x << " , " << curr_waypoint.translation.y;
		std::cout << "\nturtle x, y = " << transform.getOrigin().x() << " , " << transform.getOrigin().y();
		std::cout << "\nr = " << turtleTheta << " (" << turtleTheta * (180.0/PI) << ")" << "   w = " << wTheta << " (" << wTheta * (180.0/PI) << ")" << "   \na = " << arctan - wTheta << " (" << (arctan - wTheta) * (180.0/PI) << ")" << "   a + w = " << arctan << " (" << arctan * (180.0/PI) << ")";
	  
	  
	  pub.publish(twist);
	  
	  /*tf::Vector3 axis=transform.getRotation().getAxis();
	  double angle=transform.getRotation().getAngle();
	  double theta=angle*axis[2];
	  std::cout<<"Robot orientation (theta): ("<<theta<<")"<<std::endl<<std::endl;
	  */
	  
	  loop.sleep();
	}
	
	return 0;
}


	
	

