#include "ros/ros.h"
#include <iostream>
#include "geometry_msgs/Transform.h"
#include <tf/tf.h>
#include <tf/transform_listener.h>
#define PI 3.14159265


geometry_msgs::Transform curr_waypoint;


void waypoint_cb(const geometry_msgs::Transform::ConstPtr& msg)
{                 
    curr_waypoint=*msg;
}

int main(int argc, char **argv){

	ros::init(argc, argv, "waypoint");
	ros::NodeHandle n;
	ros::Subscriber sub = n.subscribe("/waypoint_cmd", 1000, waypoint_cb);
	ros::Publisher pub = n.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/navi", 1000);
	
	tf::TransformListener listener;
	
	ros::Rate loop(2.0);
	while(ros::ok()){
	  ros::spinOnce();
	  
	  tf::StampedTransform transform;
	  
	  try{
	    
	    listener.lookupTransform("/odom", "/base_link", ros::Time(0), transform);
	  }
	  
	  catch (tf::TransformException ex){
	    ROS_ERROR("%s",ex.what());
	    ros::Duration(1.0).sleep();
	  }
	  
	  tf::Vector3 turtleAxis=transform.getRotation().getAxis();
	  double turtleAngle=transform.getRotation().getAngle();
	  double turtleTheta=turtleAngle * turtleAxis[2];
	  
	  tf::Quaternion wQuat(curr_waypoint.rotation.x,curr_waypoint.rotation.y,curr_waypoint.rotation.z,curr_waypoint.rotation.w);
	  tf::Vector3 wAxis=wQuat.getAxis();
	  double wAngle=wQuat.getAngle();
	  double wTheta=wAngle * wAxis[2];
	 
		
	  
	  geometry_msgs::Twist twist;
	  

	  double atanValue = atan2((curr_waypoint.translation.y - transform.getOrigin().y()),(curr_waypoint.translation.x - transform.getOrigin().x()));
	  if(turtleTheta > PI) turtleTheta -= 2 * PI;

	  if(turtleTheta > 0 && atanValue < 0 && fabs(turtleTheta - atanValue) > PI) twist.angular.z = -1 * (turtleTheta - (2 * PI + atanValue));
	  else if(turtleTheta < 0 && atanValue > 0 && fabs(atanValue - turtleTheta) > PI) twist.angular.z =  -1 * ((2 * PI + turtleTheta ) - atanValue);
	  else twist.angular.z = -1 * (turtleTheta - atanValue);
	  
	  twist.linear.x = 0.5 * sqrt( pow((curr_waypoint.translation.x - transform.getOrigin().x()), 2) + pow((curr_waypoint.translation.y - transform.getOrigin().y()), 2) );
      if(twist.linear.x < 0.005) twist.linear.x = 0.005;
      
      if((twist.angular.z > PI/2 || twist.angular.z < -1 * (PI/2)) && (fabs(turtleTheta - wTheta) < PI/4)){
		twist.linear.x = -1 * twist.linear.x;
		atanValue = atan2((transform.getOrigin().y() - curr_waypoint.translation.y), (transform.getOrigin().x() - curr_waypoint.translation.x));
		twist.angular.z = -1 * (wTheta - atanValue);
		
		
	  }



      std::cout << "arctan(y/x) = " << atanValue << std::endl;
      std::cout << "arctan(y/x)(degree) = " << atanValue * 180 / PI << std::endl;	  
	  std::cout << "angular.z = " << twist.angular.z <<std::endl;
	  std::cout << "angular.z(degree) = " << twist.angular.z * 180 / PI <<std::endl;
	  std::cout << "linear.x = " << twist.linear.x << std::endl << std::endl;

	  	  
	  std::cout << "Current waypoint (x,y): ("<<curr_waypoint.translation.x<<","<<curr_waypoint.translation.y<<")"<<std::endl;
	  std::cout << "Current waypoint (theta): ("<<wTheta<<")"<<std::endl;
	  std::cout << "Current waypoint (theta)(degree): ("<< wTheta * 180 / PI <<")"<<std::endl<<std::endl;

	  std::cout << "Robot position (x,y): ("<<transform.getOrigin().x()<<","<<transform.getOrigin().y()<<")"<<std::endl;
	  std::cout << "Robot orientation (theta): ("<<turtleTheta<<")"<<std::endl;
	  std::cout << "Robot orientation (theta)(degree): ("<< turtleTheta * 180 / PI <<")"<<std::endl<<std::endl;


	  
	  pub.publish(twist);
	  loop.sleep();
	}
	
	return 0;
}


	
	
