/* Robotics - BLG456E
 * Assignment 1
 * M.Habib Beyatlı
 * 150120048
 * */
 
	//std::cout<<"Number of points in laser scan is: "<<laser_ranges.size()<<std::endl;
    //std::cout<<"The distance to the rightmost scanned point is "<<laser_ranges[0]<<std::endl;
    //std::cout<<"The distance to the leftmost scanned point is "<<laser_ranges[laser_ranges.size()-1]<<std::endl;
    //std::cout<<"The distance to the middle scanned point is "<<laser_ranges[laser_ranges.size()/2]<<std::endl;

    //std::cout<<"The minimum angle scanned by the laser is "<<laser_msg.angle_min<<std::endl;
    //std::cout<<"The maximum angle scanned by the laser is "<<laser_msg.angle_max<<std::endl;
    //std::cout<<"The increment in angles scanned by the laser is "<<laser_msg.angle_increment<<std::endl; //should be that angle_min+angle_increment*laser_ranges.size() is about angle_max
    //std::cout<<"The minimum range (distance) the laser can perceive is "<<laser_msg.range_min<<std::endl;
    //std::cout<<"The maximum range (distance) the laser can perceive is "<<laser_msg.range_max<<std::endl;


#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "sensor_msgs/LaserScan.h"
#include "nav_msgs/OccupancyGrid.h"
#include <iostream>

ros::Publisher motor_command_publisher;
ros::Subscriber laser_subscriber;
ros::Subscriber map_subscriber;

sensor_msgs::LaserScan laser_msg;
nav_msgs::OccupancyGrid map_msg;
geometry_msgs::Twist motor_command;

void laser_callback(const sensor_msgs::LaserScan::ConstPtr& msg)
{
	//The robot isn't move smart. But somehow find a way and travel the map. 
	//I couldn't find an algorithm which exactly travel whole the map. Therefore, I choose this a rough-and-tumble way.
	//Sometimes it rubs the wall because of acceleration. However, that's not a permanent disability.
	
    laser_msg=*msg;
    std::vector<float> laser_ranges;
    laser_ranges=laser_msg.ranges; 
    
    if(laser_ranges[320]<1)
	{
			motor_command.angular.z=0.1;
			motor_command.linear.x=-1.0;
			std::cout << "Geri" << std::endl;
	}
    
    else if(laser_ranges[250]<0.8 ||laser_ranges[200]<0.8 || laser_ranges[150]<0.8 || laser_ranges[100]<0.8  || laser_ranges[50]<0.8)
    {
		motor_command.angular.z=2.5;
		motor_command.linear.x=0.5;	
		 std::cout << "Sol" << std::endl;
	}
	
	 else if(laser_ranges[390]<0.8 || laser_ranges[440]<0.8 || laser_ranges[490]<0.8 || laser_ranges[540]<0.8  || laser_ranges[590]<0.8)
    {
		motor_command.angular.z=-2.5;
		motor_command.linear.x=0.5;		
		std::cout << "Sag" << std::endl;
	}  
		
	else 
    {
		motor_command.angular.z=-0.01;
		motor_command.linear.x=1.5;
		std::cout << "Orta" << std::endl;
	}
    
    motor_command_publisher.publish(motor_command);
    

}

void map_callback(const nav_msgs::OccupancyGrid::ConstPtr& msg) {
    const bool chatty_map=false;
    map_msg=*msg;
    double map_width=map_msg.info.width;
    double map_height=map_msg.info.width;
    double map_origin_x = map_msg.info.origin.position.x;
    double map_origin_y = map_msg.info.origin.position.y;
    double map_orientation = acos(map_msg.info.origin.orientation.z);
    std::vector<signed char > map = map_msg.data;
    if(chatty_map)std::cout<<"------MAP:------"<<std::endl;
    for(unsigned int x=0; x<map_width; x++) {
        for(unsigned int y=0; y<map_height; y++) {
            unsigned int index = x + y*map_width;
            if(map[index] > 50) { 
                if(chatty_map)std::cout<<"X";
            } else if(map[index]>=0) {
                if(chatty_map)std::cout<<" ";
            } else {
                if(chatty_map)std::cout<<"?";
            }
        }
        if(chatty_map)std::cout<<std::endl;
    }
    if(chatty_map)std::cout<<"----------------"<<std::endl;
}

int main(int argc, char **argv){
    ros::init(argc, argv, "amble");
    ros::NodeHandle n;
	motor_command_publisher = n.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/navi", 100);
    laser_subscriber = n.subscribe("/scan", 1000,laser_callback);
    //map_subscriber = n.subscribe("/map", 1000,map_callback);
    ros::Duration time_between_ros_wakeups(0.001);
    while(ros::ok()) {
        ros::spinOnce();
        time_between_ros_wakeups.sleep();
    }
    return 0;
}
