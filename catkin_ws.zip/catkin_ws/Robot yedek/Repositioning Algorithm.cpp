/* Robotics Project Source Code
 * UpROS Cargo
 * Muhammed Habib Beyatlı
 * 150120048
 * */

#include <iostream>
#include <math.h>
#include <string.h>
using namespace std;

	class robot{
		public:
			float x;
			float y;
			char name[10];
		}tosunlar[3];

int main(){

	tosunlar[0].x=2;
	tosunlar[0].y=6;
	strcpy(tosunlar[0].name,"Michael");
	
	tosunlar[1].x=10;
	tosunlar[1].y=9;
	strcpy(tosunlar[1].name,"Vladimir");
	
	tosunlar[2].x=12;
	tosunlar[2].y=3;
	strcpy(tosunlar[2].name,"Kyle");

	float ox,oy,dx,dy,tempx,tempy;
	int holder,holder2,i;
	int rco,rcd;
	char tempname[10];

	while(1)
	{
		cout << "Give the OBJECT coordinates :";
		cin >> ox >> oy;
		cout << "Give the DESTINATION coordinates :";
		cin >> dx >> dy;

		holder = 500;
        holder2 = 500;
		for(i=0;i<3;i++)
		{
			if(holder > pow(tosunlar[i].x-ox,2)+pow(tosunlar[i].y-oy,2))
			{
                holder = pow(tosunlar[i].x-ox,2)+pow(tosunlar[i].y-oy,2);
                rco = i;
                strcpy(tempname,tosunlar[rco].name);
			}
		}

		for(i=0;i<3;i++)
		{
			if(holder2 > pow(tosunlar[i].x-dx,2)+pow(tosunlar[i].y-dy,2))
			{
                holder2 = pow(tosunlar[i].x-dx,2)+pow(tosunlar[i].y-dy,2);
                rcd = i;
			}
		}
		
		cout << "The closest robot is :" << tempname << endl;
		
		if((rco == 1 || rcd == 1) && (rco != rcd))
		{
			strcpy(tempname,tosunlar[rco].name);
			strcpy(tosunlar[rco].name,tosunlar[rcd].name);
			strcpy(tosunlar[rcd].name,tempname);
			
		}
		
		if( ((rco == 0) && (rcd == 2))  || ((rco == 2) && (rcd == 0)) )
		{
			if(rco == 0)
			{
				strcpy(tempname,tosunlar[0].name);
				strcpy(tosunlar[0].name,tosunlar[1].name);
				strcpy(tosunlar[1].name,tosunlar[2].name);
				strcpy(tosunlar[2].name,tempname);	
			}
			
			if(rco == 2)
			{
				strcpy(tempname,tosunlar[2].name);
				strcpy(tosunlar[2].name,tosunlar[1].name);
				strcpy(tosunlar[1].name,tosunlar[0].name);
				strcpy(tosunlar[0].name,tempname);	
			}
			
		}
		
		
		for(i=0;i<3;i++)
		{
			cout << "In the " << tosunlar[i].x << " X-Coor " << tosunlar[i].y << " Y-Coor robot is :" << tosunlar[i].name << endl; 
		}
		cout << endl;
	}


	return 0;
}
